/**
 * Created by Alys1 on 3/5/15.
 */
//Emily Davis - Output Assignment - Scalable Data Infrastructures - MDV2330-0 - March 5, 2015
//Boolean Variable