/**
 * Created by Alys1 on 3/5/15.
 */
//Emily Davis - Output Assignment - Scalable Data Infrastructures - MDV2330-0 - March 5, 2015
//String Variable

var popup1 = "Did you know...";
//declaring the existence of the first variable and what it is called. Assigning a value to the variable.
alert(popup1);
//new popup window

var popup2 = "...that I love to design...";
//declaring the existence of the second variable and what it is called. Assigning a value to the variable.
alert(popup2);
//new popup window

var popup3 = "...AND develop?";
//declaring the existence of the third variable and what it is called. Assigning a value to the variable.
alert(popup3);
//new popup window

var popup4 = "Weird. Huh?";
//declaring the existence of the fourth variable and what it is called. Assigning a value to the variable.
alert(popup4);
//new popup window.